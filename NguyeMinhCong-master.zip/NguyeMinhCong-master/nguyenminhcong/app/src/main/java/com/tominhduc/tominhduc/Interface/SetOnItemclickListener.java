package com.tominhduc.tominhduc.Interface;

import android.view.View;

public interface SetOnItemclickListener {
    public void onclick(View view,int posstion);
}
