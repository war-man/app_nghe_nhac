package com.tominhduc.tominhduc.Model;

import java.util.List;

public class Test {
    public  static int vitri =-1;
    public static ListMusic listMusics;
}
