package com.tominhduc.tominhduc.Interface;

import com.tominhduc.tominhduc.Model.ListMusic;

import java.util.List;

public interface Datasend {
    public void send(List<ListMusic> listMusic,int vitri);
}
