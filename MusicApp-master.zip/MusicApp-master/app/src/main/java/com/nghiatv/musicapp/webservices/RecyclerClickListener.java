package com.nghiatv.musicapp.webservices;

import android.view.View;

public interface RecyclerClickListener {
    void onClick(View view, int position, boolean isLongClick);
}
