package com.nghiatv.musicapp.permissions;

public interface PermissionCallback {
    void permissionGranted();

    void permissionRefused();
}