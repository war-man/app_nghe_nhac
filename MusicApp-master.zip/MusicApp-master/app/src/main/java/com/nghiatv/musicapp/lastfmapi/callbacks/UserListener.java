package com.nghiatv.musicapp.lastfmapi.callbacks;

public interface UserListener {
    void userSuccess();

    void userInfoFailed();

}
