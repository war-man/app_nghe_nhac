package com.nghiatv.musicapp.listeners;

import android.annotation.TargetApi;
import android.transition.Transition;

@TargetApi(21)
public class SimplelTransitionListener implements Transition.TransitionListener {
    private static final String TAG = "SimplelTransitionListener";

    public void onTransitionCancel(Transition paramTransition) {
    }

    public void onTransitionEnd(Transition paramTransition) {
    }

    public void onTransitionPause(Transition paramTransition) {
    }

    public void onTransitionResume(Transition paramTransition) {
    }

    public void onTransitionStart(Transition paramTransition) {
    }
}