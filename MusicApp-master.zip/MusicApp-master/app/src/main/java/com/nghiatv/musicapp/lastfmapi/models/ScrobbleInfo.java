package com.nghiatv.musicapp.lastfmapi.models;

/**
 * Created by christoph on 17.07.16.
 */
public class ScrobbleInfo {
}
