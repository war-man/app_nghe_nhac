package com.nghiatv.musicapp.dto;

public class MyVideo {
    private String mVideoUrl;

    public MyVideo(String mVideoUrl) {
        this.mVideoUrl = mVideoUrl;
    }

    public String getmVideoUrl() {
        return mVideoUrl;
    }

    public void setmVideoUrl(String mVideoUrl) {
        this.mVideoUrl = mVideoUrl;
    }
}
