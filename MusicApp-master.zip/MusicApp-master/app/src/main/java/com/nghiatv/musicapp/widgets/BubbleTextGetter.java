package com.nghiatv.musicapp.widgets;

public interface BubbleTextGetter {
    String getTextToShowInBubble(int pos);
}