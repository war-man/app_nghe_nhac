Demo APP

<img src="https://github.com/luongchung/App_Android_GreatMusic/blob/master/graphics/Screenshot_20170614-203322.png" width="360" height="640">
<img src="https://github.com/luongchung/App_Android_GreatMusic/blob/master/graphics/Screenshot_20170614-203338.png" width="360" height="640">
<img src="https://github.com/luongchung/App_Android_GreatMusic/blob/master/graphics/Screenshot_20170614-203347.png" width="360" height="640">
<img src="https://github.com/luongchung/App_Android_GreatMusic/blob/master/graphics/Screenshot_20170614-203421.png" width="360" height="640">
<img src="https://github.com/luongchung/App_Android_GreatMusic/blob/master/graphics/Screenshot_20170614-203448.png" width="360" height="640">

