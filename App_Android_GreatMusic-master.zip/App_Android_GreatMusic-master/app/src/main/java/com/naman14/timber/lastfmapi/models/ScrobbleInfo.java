package com.naman14.timber.lastfmapi.models;

/**
 * Created by christoph on 17.07.16.
 */
public class ScrobbleInfo {
}
