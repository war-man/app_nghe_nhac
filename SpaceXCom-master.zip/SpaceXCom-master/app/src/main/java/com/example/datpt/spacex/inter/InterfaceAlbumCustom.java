package com.example.datpt.spacex.inter;

public interface InterfaceAlbumCustom {
    public void onAlbmclick(int position);
}
