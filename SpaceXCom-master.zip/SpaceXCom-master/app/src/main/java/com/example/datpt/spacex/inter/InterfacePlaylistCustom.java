package com.example.datpt.spacex.inter;

import com.example.datpt.spacex.item.LikeSong;

import java.util.ArrayList;

public interface InterfacePlaylistCustom {
    public void playList(ArrayList<LikeSong> songArrayList, int position);
}
