package com.example.datpt.spacex.item;

public class SongSearch {
    private String name,nameAlbum,numOfSong, thumbnail;

    public SongSearch() {
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getNameAlbum() {
        return nameAlbum;
    }

    public void setNameAlbum(String nameAlbum) {
        this.nameAlbum = nameAlbum;
    }

    public String getNumOfSong() {
        return numOfSong;
    }

    public void setNumOfSong(String numOfSong) {
        this.numOfSong = numOfSong;
    }

    public String getThumbnail() {
        return thumbnail;
    }

    public void setThumbnail(String thumbnail) {
        this.thumbnail = thumbnail;
    }
}
