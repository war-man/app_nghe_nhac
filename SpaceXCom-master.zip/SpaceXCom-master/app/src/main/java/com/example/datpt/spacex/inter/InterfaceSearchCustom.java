package com.example.datpt.spacex.inter;

public interface InterfaceSearchCustom {
   void playSearch(int positions);

}
