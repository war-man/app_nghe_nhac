package com.example.datpt.spacex.inter;

import com.example.datpt.spacex.item.Song;

import java.util.ArrayList;

public interface InterfaceSongClickCustom {
    void onSongClick(ArrayList<Song> arrayList, int position);
}
