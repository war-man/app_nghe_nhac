package com.example.huongthutran.sunmusic.NetWork;

/**
 * Created by Huong Thu Tran on 4/27/2018.
 */

public enum ApiType {
    GET_SONG,
    GET_SONG_TOP,
    GET_USER,
    GET_PLAYLIST,
    GET_PLAYLIST_TOP,
    GET_CATEGORY,
    POST_USER,
    PUT_USER,
    POST_PLAYLIST,
    POST_SONGLIST,
    GET_RATING,
    POST_RATING,
    DELETE_SONGLIST,
    PUT_RATING,
    DELETE_PLAYLIST

}
