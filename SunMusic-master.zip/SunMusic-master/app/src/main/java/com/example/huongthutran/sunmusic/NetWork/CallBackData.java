package com.example.huongthutran.sunmusic.NetWork;

/**
 * Created by Huong Thu Tran on 4/27/2018.
 */

public interface CallBackData {
    void Callback(ApiType apiType, String json);
}
