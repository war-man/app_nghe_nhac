package com.example.huongthutran.sunmusic.NetWork;

/**
 * Created by Huong Thu Tran on 4/27/2018.
 */

public class HttpParam {
    public String param;
    public String value;
    public HttpParam(){

    }
    public HttpParam(String param, String value) {
        this.param = param;
        this.value = value;
    }
}
