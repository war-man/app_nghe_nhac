package com.example.huongthutran.sunmusic.Util;

public class Constant {
    public static String baseURL = "http://192.168.42.105:9000/";
    public static int TOP_PLAYLIST=3;
    public static int TOP_SONG=6;
}
