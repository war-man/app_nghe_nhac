package com.example.huongthutran.sunmusic.Model;

public class State {
    public static String STOP = "STOP";
    public static String PLAY = "PLAY";
    public static String PAUSE = "PAUSE";
    public static String PLAYER_SHOW = "SHOW";
    public static String PLAYER_CLOSE = "CLOSE";
}
